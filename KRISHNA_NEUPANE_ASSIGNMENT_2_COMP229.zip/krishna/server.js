const express = require("express");
const Product = require("./Marketplace/productcollection");
const cors = require('cors');
const app = express();

app.use(express.json());
app.use(cors()); // use CORS middleware

const PORT = process.env.PORT || 7000; // allow port to be set by environment variables

// Welcome message
app.get("/", (req, res) => {
    res.json({ message: "Welcome to the marketplace app" });
});

// Getting all the products or products by name
app.get("/api/products", async (req, res, next) => {
    const { name } = req.query;

    try {
        let products;
        if (name) {
            products = await Product.find({ name: new RegExp(name, 'i') });
        } else {
            products = await Product.find({});
        }

        if (!products || products.length === 0) {
            return res.status(404).json({ message: "No products found" });
        }

        res.status(200).json(products);
    } catch (error) {
        console.error(error);
        next(error); // pass error to the error handling middleware
    }
});

// Getting the product with a specific id
app.get("/api/products/:id", async (req, res, next) => {
    try {
        const { id } = req.params;
        const product = await Product.findById(id);
        if (!product) {
            return res.status(404).json({ message: `Cannot find any product with ID ${id}` });
        }
        res.status(200).json(product);
    } catch (error) {
        console.error(error);
        next(error);
    }
});

// Adding a product into the database
app.post("/api/products", async (req, res, next) => {
    try {
        // validation can be added here
        const product = new Product(req.body);
        await product.save();
        res.status(201).json(product);
    } catch (error) {
        console.error(error);
        next(error);
    }
});

// Updating a product in the database
app.put("/api/products/:id", async (req, res, next) => {
    try {
        const { id } = req.params;
        const updatedProduct = await Product.findByIdAndUpdate(id, req.body, { new: true });
        if (!updatedProduct) {
            return res.status(404).json({ message: `Cannot find any product with ID ${id}` });
        }
        res.status(200).json(updatedProduct);
    } catch (error) {
        console.error(error);
        next(error);
    }
});

// Deleting the product from the database using a specific id
app.delete("/api/products/:id", async (req, res, next) => {
    try {
        const { id } = req.params;
        const deletedProduct = await Product.findByIdAndDelete(id);
        if (!deletedProduct) {
            return res.status(404).json({ message: `Cannot find any product with ID ${id}` });
        }
        res.status(200).json({ message: "Product deleted successfully." });
    } catch (error) {
        console.error(error);
        next(error);
    }
});

// Deleting all the products from the database
app.delete("/api/products", async (req, res, next) => {
    try {
        // ensure proper authentication and authorization here
        await Product.deleteMany({});
        res.status(204).json({ message: "All products have been deleted successfully." });
    } catch (error) {
        console.error(error);
        next(error);
    }
});

// Searching for products by keyword in name
app.get("/api/products/search", async (req, res, next) => {
    const { kw } = req.query; // "kw" stands for "keyword"

    if (!kw) {
        return res.status(400).json({ message: "No keyword provided" });
    }

    try {
        // Using a RegExp to search for products that contain the keyword in their name, case-insensitive
        const products = await Product.find({ name: new RegExp(kw, 'i') });

        if (!products || products.length === 0) {
            return res.status(404).json({ message: `No products found containing "${kw}"` });
        }

        res.json(products);
    } catch (error) {
        console.error(error);
        next(error); // pass error to the error handling middleware
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Internal Server Error' });
});

app.listen(PORT, () => {
    console.log(`Server running at ${PORT}`);
});
